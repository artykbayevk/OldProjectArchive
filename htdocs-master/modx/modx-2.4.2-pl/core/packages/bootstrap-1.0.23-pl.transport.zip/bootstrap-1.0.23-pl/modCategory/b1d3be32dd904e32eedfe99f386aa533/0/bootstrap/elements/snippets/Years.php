<?php
/**
 * Years snippet
 *
 * @package Bootstrap
 */
return date('Y');
