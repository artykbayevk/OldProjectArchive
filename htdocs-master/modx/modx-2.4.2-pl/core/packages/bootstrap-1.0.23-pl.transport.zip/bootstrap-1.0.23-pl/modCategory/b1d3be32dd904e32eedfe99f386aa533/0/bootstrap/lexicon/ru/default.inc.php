<?php 
/**
 * Russian Lexicon Entries for Bootstrap
 *
 * @package Bootstrap
 * @subpackage lexicon
 */
$_lang['setting_bootstrap.dropdown_disabled'] = 'Поведение меню Bootstrap';
$_lang['setting_bootstrap.dropdown_disabled_desc'] = 'Включает (1) либо выключает (0) возможность кликнуть на верхнем элементе меню и перейти на соответствующую страницу.';
