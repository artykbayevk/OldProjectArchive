angular.module('MyApp', ['ngRoute','ngCookies','btford.socket-io'])
  .config(['$locationProvider', '$routeProvider' ,function($locationProvider,$routeProvider) {
    $locationProvider.html5Mode(true);

    $routeProvider
      .when('/', {
        templateUrl: 'views/home.html',
        controller: 'MainCtrl'
      })
      .when('/check', {
        templateUrl: 'views/check.html',
        controller: 'CheckCtrl'
      })
      .when('/documentation', {
        templateUrl: 'views/tutorial/get-started.html',
        controller: 'TutorialCtrl'
      })
      .when('/documentation.get-started', {
        templateUrl: 'views/tutorial/get-started.html',
        controller: 'TutorialCtrl'
      })
      .when('/documentation.icons', {
        templateUrl: 'views/tutorial/icons.html',
        controller: 'TutorialCtrl'
      })
      .when('/documentation.inputs', {
        templateUrl: 'views/tutorial/inputs.html',
        controller: 'TutorialCtrl'
      })
      .when('/documentation.fonts', {
        templateUrl: 'views/tutorial/fonts.html',
        controller: 'TutorialCtrl'
      })
      .when('/loginForm', {
        templateUrl: 'views/logForm.html',
        controller: 'LoginCtrl'
      })
      .when('/regForm', {
        templateUrl: 'views/regForm.html',
        controller: 'SignupCtrl'
      })
      .when('/admin', {
        templateUrl: 'views/admin.html',
        controller: 'AdminCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  }]);

// 
//   $(document).ready(function(){
//     jQuery(function(){
//     $(window).scroll(function(){
//       console.log($(window).scrollTop());
//       if($(window).scrollTop()>210){
//           $('.right-nav').css({'position':'fixed','right':'0','top':'0'});
//           $('.navigation').css({'margin-top':'10'});
//       }else{
//           $('.right-nav').css({'position':'relative'});
//           $('.navigation').css({'margin-top':'100px'});
//       }
//     });
//   });
// });
