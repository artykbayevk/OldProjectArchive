angular.module('MyApp')
  .controller('MainCtrl', ['$scope', 'Auth',function($scope, Auth) {
    $scope.logout = function() {
      Auth.logout();
    };
  }])
  .controller('AdminCtrl', ['$scope','$http', 'mySocket', function($scope, $http, mySocket) {
    $http.get('http://localhost:3000/api/get-users')
    .success(function(users){
      $scope.users = users;
    }).error(function(data,status){
      console.log(data);
      console.log(status);
    });
    mySocket.forward('admin',$scope);
    $scope.$on('socket:admin',function(ev,data){
      $scope.users.splice(0,0,data.msg);
    });

    $scope.onGivePermission = function(user){
      var data = {
        ID: user._id
      }
    $http.post('http://localhost:3000/api/give-permission',data)
      .success(function(result){
        var index = $scope.users.indexOf(user);
        $scope.users.splice(index,1);
        alert('Вы дали разрешение польсователю с почтовым ящиком: ' + user.email);
      })
      .error(function(data,status){
        alert(data);
      });
    console.log(data.ID);
  }
  }])
  .controller('CheckCtrl', ['$scope', 'Auth', function($scope, Auth) {

  }])
  .controller('TutorialCtrl', ['$scope', 'Auth', function($scope, Auth) {

  }])
  .controller('SignupCtrl', ['$scope', 'Auth', function($scope, Auth) {
    $scope.signup = function() {
      Auth.signup({
        email: $scope.email,
        password: $scope.password
      });
    };
  }])
  .controller('LoginCtrl', ['$scope', 'Auth', function($scope, Auth) {
    $scope.login = function() {
      Auth.login({
        email: $scope.email,
        password: $scope.password
      });
    };
  }]);;
