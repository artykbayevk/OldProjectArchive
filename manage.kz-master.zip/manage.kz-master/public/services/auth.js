angular.module('MyApp')
  .factory('Auth', ['$http', '$location', '$rootScope', '$cookieStore','mySocket',
    function($http, $location, $rootScope, $cookieStore,mySocket) {
      $rootScope.currentUser = $cookieStore.get('user');
      return {
        login: function(user) {
          return $http.post('/api/login', user)
            .success(function(data) {
              $rootScope.currentUser = data;
              if(data.role){
                $location.path('/admin');
              }else{

                $location.path('/documentation');
              }
            })
            .error(function() {
              alert('Вы ввели неправильный логин или пароль, или вам еще не дали разрешение.');
            });
        },
        signup: function(user) {
          return $http.post('/api/signup', user)
            .success(function(response) {
              mySocket.emit('signup', response);
              alert('Ваша заявка принята, ожидайте.');
              $location.path('/');
            })
            .error(function(response) {
              alert('Пользователь с такой почтой уже существует.');
            });
        },
        logout: function() {
          return $http.get('/api/logout')
          .success(function() {
            $rootScope.currentUser = null;
            $cookieStore.remove('user');
            $location.path('/admin')
          })
          .error(function(response){
            $location.path('/admin');
          });
        }
      };
    }]);
