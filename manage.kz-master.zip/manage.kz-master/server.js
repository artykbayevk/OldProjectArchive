var express = require('express');
var path = require('path');
var favicon = require('static-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var jwt = require('jwt-simple');
var bcrypt = require('bcryptjs')
var session = require('express-session');
var MongoStore = require('connect-mongo')(session);
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;


mongoose.connect('localhost');


var userSchema = new mongoose.Schema({
  email: String,
  password: String,
  isChecked: Boolean,
  role: Boolean
});

userSchema.pre('save', function(next) {
  var user = this;
  if (!user.isModified('password')) return next();
  bcrypt.genSalt(10, function(err, salt) {
    if (err) return next(err);
    bcrypt.hash(user.password, salt, function(err, hash) {
      if (err) return next(err);
      user.password = hash;
      next();
    });
  });
});

userSchema.methods.comparePassword = function(candidatePassword, cb) {
  bcrypt.compare(candidatePassword, this.password, function(err, isMatch) {
    if (err) return cb(err);
    cb(null, isMatch);
  });
};
passport.use(new LocalStrategy({ usernameField: 'email' }, function(email, password, done) {
  User.findOne({ email: email ,isChecked:true}, function(err, user) {
    if (err) return done(err);
    if (!user) {return done(null, false);
      console.log('Юзера нету');
    }
    user.comparePassword(password, function(err, isMatch) {
      if (err) {
        console.log('Пароль не правильный');
        return done(err);
      }
      if (isMatch) {
        console.log('Получилось');
        return done(null, user);
      }
      return done(null, false);
    });
  });
}));

var User = mongoose.model('User', userSchema);

var app = express()
app.set('port', process.env.PORT || 3000);
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(favicon());
app.use(session({
  secret: 'keyboard cat',
  resave: true,
  saveUninitialized:true,
  store: new MongoStore({ mongooseConnection: mongoose.connection })
}));
app.use(passport.initialize());
app.use(passport.session());

function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()){
    console.log('Он авторизован');
    next();
}
  else res.send(401,"У тебя есть проблемы");
}

passport.serializeUser(function(user, done) {
  console.log('serializeUser');
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  User.findById(id, function(err, user) {
    console.log('deserializeUser');
    done(err, user);
  });
});
app.use(function(req, res, next) {
    if (req.user) {
        res.cookie('user', JSON.stringify(req.user));
    }
    next();
});

 app.use('/admin', function(req,res,next){
   if(!req.user){
      res.redirect('/#loginForm');
    }
   else if(!req.user.role){
     res.redirect('/#check');
   }else{
     next();
   }
 });
 app.use('/loginForm', function(req,res,next){
   if(!req.user){
      res.redirect('/#loginForm');
    }else{
      res.redirect('/#');
    }
 });
app.use('/check', function(req,res,next){
  if(!req.user) res.redirect('/#loginForm');
  else{
    next();
  }
});

app.post('/api/signup', function(req, res, next) {
  var user = new User({
    email: req.body.email,
    password: req.body.password,
    isChecked:false,
    role:false
  });
  user.save(function(err,data) {
    if (err) return next(err);
    res.send(200,data);
  });
});

app.post('/api/login', passport.authenticate('local'), function(req, res) {
  res.cookie('user', JSON.stringify(req.user));
  res.send(req.user);
});

app.get('/api/get-users',function(req,res){
  User.find({isChecked: false} , function(err, users){
    if(err){
      return console.log(err);
    }
    res.send(users);
  }).sort({ _id : -1 });
});

// POST give permission to user
app.post('/api/give-permission', function(req,res){
  var userID = req.body.ID;
  User.update(
    { _id: userID},
    {$set: {isChecked: true}}
  ,function(err,user){
    if(!user){
      return res.send({result: 'error'});
    }else{
      return res.send({result: 'success'});
    }
  });
});

app.get('*', function(req, res) {
  res.redirect('/#' + req.originalUrl);
});

app.use(function(err, req, res, next) {
  console.error(err.stack);
  res.send(500, { message: err.message });
});

var server = app.listen(app.get('port'), function() {
  console.log('Express server listening on port ' + app.get('port'));
});




var io = require('socket.io')();
io.attach(server);
io.sockets.on('connection',function(socket){

socket.on('signup', function(data){
  socket.broadcast.emit('admin',{msg:data});
});
})
