from django.contrib import admin
from web.models import User,Subs,Some,Busket,Order
admin.site.register(User)
admin.site.register(Subs)
admin.site.register(Some)
admin.site.register(Busket)
admin.site.register(Order)
