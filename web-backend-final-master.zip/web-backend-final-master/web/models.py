from django.db import models
import os
from django.utils import timezone
from datetime import datetime

# Create your models here.
class Ex(models.Model):
    name = models.ImageField(upload_to='web/static/files', blank=True, verbose_name='подпись')

class User(models.Model):
    name = models.CharField(max_length=30)
    surname = models.CharField(max_length=30)
    login = models.CharField(max_length=30)
    image = models.ImageField(upload_to='web/static/images', blank=True, verbose_name='My photo')
    email = models.EmailField(max_length=50)
    password = models.CharField(max_length=30)
    text = models.CharField(max_length=100)
    gender = models.CharField(max_length=30)

class Subs(models.Model):
    email = models.EmailField(max_length=40)
    date = models.DateTimeField(default=timezone.now,blank=True)

class Some(models.Model):
    name = models.CharField(max_length=30)
    size = models.CharField(max_length=30)
    types = models.CharField(max_length=30)
    image = models.ImageField(upload_to='web/static/images/goods', blank=True, verbose_name='My photo')
    text = models.CharField(max_length=30)
    date = models.DateTimeField(default=timezone.now,blank=True)
    nameImage = models.CharField(max_length=100)
    price = models.CharField(max_length=30)

class Busket(models.Model):
    name = models.CharField(max_length=30)
    size = models.CharField(max_length=30)
    types = models.CharField(max_length=30)
    price = models.CharField(max_length=30)
    customer = models.CharField(max_length=30)

class Order(models.Model):
    customer = models.CharField(max_length=30)
    orders = models.CharField(max_length=300)
