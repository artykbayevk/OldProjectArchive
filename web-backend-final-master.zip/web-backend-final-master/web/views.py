from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from web.models import Ex,User,Subs,Some,Busket,Order
import datetime
from django.db.models import Q
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

#VIEWS
def index(request):
    if request.session.has_key('login'):
        data = {
            'login':request.session['login'],
        }
        return render(request,'index.html',{'data':data})
    else:
        data = {
            'login':'logout',
        }
        return render(request,'index.html',{'data':data})

def second(request):
    if request.session.has_key('login'):
        obj = Some.objects.filter(types='MAN')
        paginator = Paginator(obj, 6)
        page = request.GET.get('page')
        try:
            contacts = paginator.page(page)
        except PageNotAnInteger:
            # If page is not an integer, deliver first page.
            contacts = paginator.page(1)
        except EmptyPage:
            # If page is out of range (e.g. 9999), deliver last page of results.
            contacts = paginator.page(paginator.num_pages)
        if obj:
            objects = contacts
        else:
            objects = 'no'
        data = {
            'login':request.session['login'],
        }
        return render(request,'man.html',{'data':data,"list": objects})
    else:
        return HttpResponseRedirect("/logPage/")

def third(request):
    if request.session.has_key('login'):
        obj = Some.objects.filter(types='WOMAN')
        paginator = Paginator(obj, 6)
        page = request.GET.get('page')
        try:
            contacts = paginator.page(page)
        except PageNotAnInteger:
            # If page is not an integer, deliver first page.
            contacts = paginator.page(1)
        except EmptyPage:
            # If page is out of range (e.g. 9999), deliver last page of results.
            contacts = paginator.page(paginator.num_pages)
        if obj:
            objects = contacts
        else:
            objects = 'no'
        data = {
            'login':request.session['login'],
        }
        return render(request,'woman.html',{'data':data,"list": objects})
    else:
        return HttpResponseRedirect("/logPage/")

def regPage(request):
    if request.session.has_key('login'):
        data = {
            'login':request.session['login'],
        }
        return render(request,'regPage.html',{'data':data})
    else:
        data = {
            'login':'logout',
        }
        return render(request,'regPage.html',{'data':data})

def logPage(request):
    if request.session.has_key('login'):
        return HttpResponseRedirect('/')
    else:
        data = {
            'login':'logout',
        }
        return render(request, 'logPage.html',{'data':data})

def subs(request):
    if request.session.has_key('login'):
        if request.session['login']=='admin':
            a = Subs.objects.all()
            if a:
                send = a
                data = {
                    'list':send,
                    'login':request.session['login'],
                    }
            else:
                data = {
                    'list':'no',
                    'login':request.session['login'],
                }
            return render(request,'subs.html',{'data':data})
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect("/logPage/")

def ordsubs(request):
    if request.session.has_key('login'):
        if request.session['login']=='admin':
            if request.method=='POST':
                var = request.POST['value']
                if var=='email':
                    a = Subs.objects.order_by('email')
                else:
                    a = Subs.objects.order_by('-date')
                if a:
                    send = a
                    data = {
                        'list':send,
                        'login':request.session['login'],
                        }
                else:
                    data = {
                    'list':'no',
                    'login':request.session['login'],
                    }
            return render(request,'subs.html',{'data':data})
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect("/logPage/")

def goodsPage(request):
    if request.session.has_key('login'):
        if request.session['login']=='admin':
            data = {
                'login':request.session['login'],
            }
            return render(request,'goodsPage.html',{'data':data})
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect("/logPage/")

def users(request):
    if request.session.has_key('login'):
        if request.session['login']=='admin':
            a = User.objects.all().filter(~Q(login='admin'))
            if a:
                send = a
                data = {
                    'list':send,
                    'login':request.session['login'],
                    }
            else:
                data = {
                    'list':'no',
                    'login':request.session['login'],
                }
            return render(request,'users.html',{'data':data})
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect("/logPage/")

def ordUsers(request):
    if request.method=='POST':
        if request.session.has_key('login'):
            var = request.POST['sort']
            send = '---'
            obj = User.objects.all().filter(~Q(login='admin'))
            if obj:
                if request.POST['sort']=='---':
                    obj = obj
                elif request.POST['sort']=='Name':
                    obj = obj.order_by('name')
                    send = 'Name'
                elif request.POST['sort']=='Surname':
                    obj = obj.order_by('surname')
                    send = 'Surname'
                elif request.POST['sort']=='Login':
                    obj = obj.order_by('login')
                    send = 'Login'
                elif request.POST['sort']=='Email':
                    obj = obj.order_by('email')
                    send = 'Email'
                elif request.POST['sort']=='Gender':
                    obj = obj.order_by('gender')
                    send = 'Gender'
                else:
                    pass
            else:
                obj = 'no'
            data = {
                'send':send,
                'list':obj,
                'login':request.session['login'],
            }
            return render(request,'users.html',{'data':data})
        else:
            return HttpResponseRedirect('/logPage/')
    else:
        return HttpResponseRedirect('/logPage/')

def userProfile(request):
    if request.session.has_key('login'):
        if request.session['login']!='admin':
            a = User.objects.all().filter(login=request.session['login'])
            data = {
                'user':a,
                'login':request.session['login'],
            }
            return render(request,'profile.html',{'data':data})
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect("/logPage/")

def mybusket(request):
    if request.session.has_key('login'):
        obj = Busket.objects.all().filter(customer=request.session['login'])
        if obj:
            data = {
                'list':obj,
                'login':request.session['login'],
            }
        else:
            data = {
                'list':'no',
                'login':request.session['login'],
            }
        return render(request,'mybusket.html',{'data':data})
    else:
        return HttpResponseRedirect('/logPage/')

def orders(request):
    if request.session.has_key('login'):
        obj = Order.objects.all()
        if obj:
            data = {
                'list':obj,
                'login':request.session['login']
            }
        else:
            data = {
                'list':'no',
                'login':request.session['login'],
            }
        return render(request,'orders.html',{'data':data})
    else:
        return HttpResponseRedirect('/logPage/')

#ACTIONS
def reg(request):
    if request.method == 'POST':
        login = request.POST['login']
        check = User.objects.filter(login=login)
        if len(check)==0:
            name = request.POST['name']
            surname = request.POST['surname']
            email = request.POST['email']
            image = request.FILES['image']
            password = request.POST['password']
            text = request.POST['text']
            gender = request.POST['gender']
            obj = User.objects.create(name=name,surname=surname,login=login,image=image,email=email,password=password,text=text,gender=gender)
            obj.save()
            return HttpResponseRedirect("/")
        return HttpResponseRedirect("/regPage/")
    else:
        return HttpResponseRedirect("/regPage/")

def log(request):
    if request.method == 'POST':
        login = request.POST['login']
        password = request.POST['password']
        check = User.objects.filter(login = login,password=password)
        if check:
            request.session['login'] = login
            return HttpResponseRedirect('/')
        else:
            return HttpResponseRedirect('/logPage/')
    else:
        return HttpResponseRedirect('/')

def subscribe(request):
    if request.method == 'POST':
        email = request.POST['email']
        a  = Subs.objects.create(email=email)
        a.save()
        return HttpResponseRedirect("/")
    else:
        return HttpResponseRedirect("/")

def logout(request):
    try:
        del request.session['login']
    except KeyError:
        pass
    return HttpResponseRedirect('/')

def delsubs(request):
    if request.method == "POST":
        a = request.POST['id']
        b = Subs.objects.filter(id = a).delete()
        return HttpResponseRedirect("/subs/")
    else:
        return HttpResponseRedirect("/subs/")

def add(request):
    if request.method=="POST":
        if request.session['login']=='admin':
            name = request.POST['name']
            obj = Some.objects.filter(name=name)
            if obj:
                return HttpResponseRedirect('/goodsPage/')
            else:
                size = request.POST['size']
                types = request.POST['type']
                image = request.FILES['image']
                text = request.POST['text']
                price = request.POST['price']
                good = Some.objects.create(name=name,size=size,types=types,image=image,text = text,nameImage=image.name,price=price)
                if good:
                    return HttpResponseRedirect('/')
                else:
                    return HttpResponse('/goodsPage/')
        else:
            HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/goodsPage/')

def crud(request):
    if request.method=="POST":
        if request.session['login']=='admin':
            val = request.POST['value']
            if val == 'MAN':
                url = '/man/'
            if val == 'WOMAN':
                url = '/woman/'
            if request.POST['type']=='edit':
                val = request.POST['id']
                obj = Some.objects.filter(id=val)
                data = {
                    'list':obj,
                    'login':request.session['login'],
                }
                return render(request,'editGoodPage.html',{'data':data})
            elif request.POST['type']=='delete':
                val = request.POST['id']
                obj = Some.objects.filter(id=val).delete()
                return HttpResponseRedirect(url)
            else:
                return HttpResponseRedirect(url)
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')

def save(request):
    if request.method=="POST":
        if request.session['login']=='admin':
            name = request.POST['name']
            types = request.POST['type']
            if types == 'MAN':
                url = '/man/'
            if types == 'WOMAN':
                url = '/woman/'
            obj = Some.objects.filter(name=name)
            if obj:
                return HttpResponseRedirect(url)
            else:
                size = request.POST['size']
                types = request.POST['type']
                text = request.POST['text']
                price = request.POST['price']
                val = request.POST['value']
                newObj = Some.objects.filter(id=val).update(name=name,size=size,types=types,text = text,price=price)
                return HttpResponseRedirect(url)
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect("/")

def delUsers(request):
    if request.method == 'POST':
        a = request.POST['id']
        b = User.objects.filter(id=a).delete()
        return HttpResponseRedirect('/users/')
    else:
        return HttpResponseRedirect('/users/')

def editPage(request):
    if request.method == 'POST':
        if request.session['login']!='admin':
            a = User.objects.all().filter(login = request.session['login'])
            data = {
                'user':a,
                'login':request.session['login']
            }
            return render(request,'editUser.html',{'data':data})
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')

def edit(request):
    if request.method=='POST':
        if request.session['login']!='admin':
            a = User.objects.all().filter(login=request.session['login']).update(name=request.POST['name'],surname=request.POST['surname'],email=request.POST['email'],text=request.POST['text'],gender=request.POST['gender'])
            return HttpResponseRedirect('/userProfile/')
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')

def addBusket(request):
    if request.method == 'POST':
        obj = Some.objects.all().filter(id=request.POST['id'])
        newObj = Busket.objects.create(name=obj.get().name,size=obj.get().size,types=obj.get().types,price=obj.get().price,customer=request.session['login'])
        newObj.save()
        if request.POST['value']=='MAN':
            url = '/man/'
        if request.POST['value']=='WOMAN':
            url = '/woman/'
        return HttpResponseRedirect(url)
    else:
        if request.POST['value']=='MAN':
            url = '/man/'
        if request.POST['value']=='WOMAN':
            url = '/woman/'
        return HttpResponseRedirect(url)

def buy(request):
    if request.method == 'POST':
        obj = Busket.objects.all().filter(customer=request.session['login'])
        order = ''
        for i in obj:
            order=i.name+','+order
        newObj = Order.objects.create(customer=request.session['login'],orders=order[:len(order)-1])
        newObj.save()
        secObj = Busket.objects.all().filter(customer=request.session['login']).delete()
        return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')

def delete(request):
    if request.method=='POST':
        obj = request.POST['ordId']
        query = Order.objects.all().filter(id=obj).delete()
        return HttpResponseRedirect('/orders/')
    else:
        return HttpResponseRedirect('/orders/')

def accept(request):
    if request.method=='POST':
        if request.session['login']=='admin':
            return HttpResponse('Accepted')
        else:
            return HttpResponseRedirect('/')
    else:
        return HttpResponseRedirect('/')
