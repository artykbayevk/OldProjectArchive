angular.module('zap24', ['ui.router','ngAnimate','ui.mask','mgcrea.ngStrap','ngCookies','btford.socket-io'])
	.config(['$locationProvider','$urlRouterProvider', '$stateProvider',function($locationProvider,$urlRouterProvider,$stateProvider){
		$locationProvider.html5Mode(true);
	    $urlRouterProvider.otherwise('/');
	    $stateProvider
	    	.state('home',{
	    		url: '/',
	    		templateUrl: 'views/home.html',
	    		controller: 'HomeController',
	    		controllerAs: 'vm'
	    	})
	    	.state('admin',{
	    		url: '/admin',
	    		templateUrl: 'views/admin.html',
	    		controller: 'AdminController'
	    	})
	    	.state('admin.top-repairs',{
	    		url: '/top-repairs',
	    		templateUrl: 'views/admin-top-repairs.html'
	    	})
	    	.state('admin.top-sellers',{
	    		url: '/top-sellers',
	    		templateUrl: 'views/admin-top-sellers.html'
	    	})
	    	.state('login',{
	    		url: '/login',
	    		templateUrl: 'views/login-form.html',
	    		controller: 'LoginController'
	    	})
	    	.state('regis',{
	    		url: '/regis',
	    		templateUrl: 'views/reg-form.html',
	    		controller: 'RegisController'
	    	})
				.state('seller-page',{
	    		url: '/seller-page',
	    		templateUrl: 'views/seller-page.html',
					controller: 'SellerePageController',
					controllerAs: 'vm'
	    	})
				.state('customer-page',{
	    		url: '/customer-page/:id',
	    		templateUrl: 'views/customer-page.html',
					controller:'CustomerPageController',
					controllerAs:'vm'
	    	})
				.state('result-page',{
	    		url: '/result-page',
	    		templateUrl: 'views/result-page.html',
					controller:'ResultPageController',
					controllerAs: 'vm'
	    	})
				.state('additional-page',{
	    		url: '/additional-page',
	    		templateUrl: 'views/additional-page.html',
					controller:'AdditionalPageController',
					controllerAs: 'vm'
	    	});
}]);
