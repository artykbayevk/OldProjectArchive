angular.module('zap24')
	.controller('AdditionalPageController',['$http','$rootScope','$scope','$state','$alert','Auth', function($http, $rootScope, $scope, $state, $alert, Auth){
		$rootScope.isHome = false;
    console.log('AdditionalPageController');
		if($rootScope.currentUser.regFinished){
			$state.go('seller-page');
		}
		console.log($rootScope.currentUser.phone);
		vm = this;
//---------------------------------------------------------------------------
		$scope.selectedCar=false;

		vm.SelectCarArray = [];
		vm.SelectMarkArray = [];
		vm.SelectedItem = [];

		vm.cars = [];
		vm.marks = [];


		vm.getCars = function(){
			return $http.get('/api/client/getcars/')
			.success(function(cars){
				vm.cars=cars;
			})
			.error(function(err,data){
				console.log(err);
			})
		}

		vm.GetMarks = function(){
			return $http.get('/api/client/getmarks/')
			.success(function(marks){
				vm.marks=marks;
			})
			.error(function(err,data){
				console.log(data);
			})
		}

		vm.getCars();
		vm.GetMarks();

		vm.selectMark = function(carMark){
			$scope.selectedCar = true;
			vm.SelectMarkArray.push(carMark);
			vm.SelectedItem.push(carMark);
		}

		vm.selectCar = function(carType,carMark){
			vm.SelectCarArray.push(carType);
			vm.SelectMarkArray.push(carMark);
			$scope.selectedCar = true;
		}

		vm.removeCar = function(index){
			vm.SelectCarArray.splice(index,1);
			vm.SelectMarkArray.splice(index,1);
			if(vm.SelectCarArray.length==0 && vm.SelectedItem.length==0){
				$scope.selectedCar=false;
			}
		}

		vm.removeMark = function(index){
			vm.SelectMarkArray.splice(index,1);
			vm.SelectedItem.splice(index,1);
		}

//---------------------------------------------------------------------------

	$scope.selectedSpare = false;

	vm.SelectComplementArray = [];
	vm.SelectSpareArray = [];
	vm.SelectSecondItem = [];

	vm.complements = [];
	vm.spares = [];

	vm.getSpares = function(){
		return $http.get('/api/client/getspares/')
		.success(function(spares){
			vm.spares=spares;
		})
		.error(function(err,data){
			console.log(err);
		})
	}
	vm.getComplements = function(){
		return $http.get('/api/client/getcomplements/')
		.success(function(complements){
			vm.complements=complements;
		})
		.error(function(err,data){
			console.log(err);
		})
	}

	vm.getSpares();
	vm.getComplements();

	vm.selectSpare = function(carSpare){
		$scope.selectedSpare = true;
		vm.SelectSpareArray.push(carSpare);
		vm.SelectSecondItem.push(carSpare);
	}

	vm.selectComplement = function(carComplement,carSpare){
		vm.SelectComplementArray.push(carComplement);
		vm.SelectSpareArray.push(carSpare);
		$scope.selectedSpare = true;
	}

	vm.removeComplement = function(index){
		vm.SelectComplementArray.splice(index,1);
		vm.SelectSpareArray.splice(index,1);
		if(vm.SelectComplementArray.length==0 && vm.SelectSecondItem.length==0){
			$scope.selectedSpare=false;
		}
	}

	vm.removeSpare = function(index){
		vm.SelectSpareArray.splice(index,1);
		vm.SelectSecondItem.splice(index,1);
	}

//---------------------------------------------------------------------------

	vm.addInfo = function(){

		console.log(vm.SelectComplementArray);
		console.log(vm.SelectSpareArray);
		console.log(vm.SelectMarkArray);
		console.log(vm.SelectCarArray);

		vm.mainMark = '';
		vm.mainCar='';
		vm.mainComplement = '';
		vm.mainSpare = '';

		if (vm.SelectCarArray.length==0) {
			vm.mainCar = '';
		}else{
			for (var i = 0; i < vm.SelectCarArray.length; i++) {
				if (vm.SelectCarArray[i]=='все') {
					vm.mainCar = 'все';
					break;
				}else{
					vm.mainCar += vm.SelectCarArray[i] + ' ';
				}
			}
		}

		for (var i = 0; i < vm.SelectMarkArray.length; i++) {
			if (vm.SelectMarkArray[i] == 'все') {
				vm.mainMark = 'все';
			}else{
				vm.mainMark += vm.SelectMarkArray[i] + ' ';
			}
		}

		if(vm.SelectComplementArray.length==0){
			vm.mainComplement='';
		}else{
			for (var i = 0; i < vm.SelectComplementArray.length; i++) {
				if(vm.SelectComplementArray[i]=='все'){
					vm.mainComplement='все';
					break;
				}else{
					vm.mainComplement += vm.SelectComplementArray[i]+' '
				}
			}
		}

		for (var i = 0; i < vm.SelectSpareArray.length; i++) {
			if (vm.SelectSpareArray[i]=='все') {
				vm.mainSpare = 'все';
				break;
			}else{
				vm.mainSpare += vm.SelectSpareArray[i]+' ';
			}
		}

		// console.log(vm.mainSpare);
		// console.log(vm.mainComplement);
		// console.log(vm.mainCar);
		// console.log(vm.mainMark);

		if(vm.mainSpare == '' && vm.mainMark == ''){
			$alert({
				title: 'Некоторые поля пусты',
				content: '<i class="icon-cross" style="float:left;color:rgba(231,76,60,1);margin-right:5px;"></i>',
				animation: 'fadeZoomFadeDown',
				type: 'danger',
				duration: 5
			});
		}else{

			var data = {
				spare:vm.mainSpare,
				complement:vm.mainComplement,
				car:vm.mainCar,
				mark:vm.mainMark,
				number:$rootScope.currentUser.phone
			};

			$http.post('/api/finish-reg',data)
				.success(function(response){
					$alert({
						title: 'Регистрация окончена',
						content: '<i class="icon-check" style="float:left;color:rgb(99,190,212);margin-right:5px;"></i>',
						animation: 'fadeZoomFadeDown',
						type: 'danger',
						duration: 5
					});
					console.log(response);
					$state.go('seller-page');
				})
				.error(function(err,data){
					$alert({
						title: 'Регистрация не окончена',
						content: '<i class="icon-cross" style="float:left;color:rgba(231,76,60,1);margin-right:5px;"></i>',
						animation: 'fadeZoomFadeDown',
						type: 'danger',
						duration: 5
					});
					console.log(err);
				});
		}
	}

}]);
