angular.module('zap24')
	.controller('AdminController',['$http','$rootScope','$scope','$state', function($http, $rootScope, $scope, $state){
		$rootScope.isHome = false;
		$state.go('admin.top-sellers');
	}]);
