angular.module('zap24')
	.controller('CustomerPageController',['$http','$rootScope','$scope','$state','Auth', function($http, $rootScope, $scope, $state, Auth){
    var vm = this;
    vm.requests = [];
    $http.get('/api/client/customer-page/'+$state.params.id)
			.success(function(response){
        vm.requests = response;
			})
			.error(function(err,data){
				console.log(err);
			});
	}]);
