angular.module('zap24')
	.controller('HomeController',['$http','$rootScope','$scope','$state','$alert','$cookieStore','$dropdown', '$timeout', function($http, $rootScope, $scope, $state, $alert, $cookieStore,$dropdown, $timeout){
		var vm = this;
		vm.SelectSpareArray=[];
		vm.marks=[];
		vm.models=[];
		vm.spares=[];
		//Main checker
		$scope.expression=false;
		$scope.expressionSecond=false;
		$scope.some=false;
		vm.funcc = function(){
			console.log('Hip');
			$scope.expression=true;
		}
		vm.secFunc = function(){
			console.log('Hip2');
			$scope.expressionSecond=true;
		}
		$scope.classYearValue=false;
		vm.classYearFunc = function(){
			$scope.classYearValue=true;
		}

		$scope.classVolumeValue = false;
		vm.classVolumeFunc = function(){
			$scope.classVolumeValue = true;
		}
		$scope.classDescValue = false;
		vm.classDescFunc = function(){
			$scope.classDescValue = true;
		}

		$rootScope.isHome = true;
		//Checker for dropdown
		$scope.additional = false;
		$scope.count=0;

		//For dropdown in form
		$scope.selectedMark=false;
		$scope.selectedModel=false;
		$scope.selectedSpare=false;
		$scope.selectMark='';
		$scope.selectModel='';
		$scope.selectSpare='';
		//Marks and Models
		vm.selectMark = function(carMark){
			$scope.selectMark=carMark;
			$scope.selectedMark=true;
		}
		vm.selectModel = function(carModel){
			$scope.selectModel=carModel;
			$scope.selectedModel=true;
		}
		vm.selectSpare = function(carSpare,index){
			$scope.selectedSpare=true;
			vm.SelectSpareArray.push(carSpare);
			$scope.additional = true;

			$timeout(function() {
				vm.found = '';
			}, 100);
		}

		vm.remove = function(index){
			vm.SelectSpareArray.splice(index,1);
			if(vm.SelectSpareArray.length==0){
				$scope.selectedSpare=false;
			}
		}
		vm.SearchMarks = function(str){
			$http.get('/api/client/getmarks/'+str)
				.success(function(marks){
					vm.marks=marks;
				})
				.error(function(err,data){
					console.log(data);
				})
		}

		vm.conclusionFunc = function(){
			$http.get('/api/client/getmarks/'+$scope.selectMark)
			.success(function(marks){
				vm.models=marks[0].models;
			})
			.error(function(err,data){
				console.log(data);
			})
		}

		vm.getSpares = function(){
			return $http.get('/api/client/getspares/')
					.success(function(spares){
						vm.spares=spares;
					})
					.error(function(err,data){
						console.log(data);
					})
			}
		vm.getSpares();


		$scope.notFound=false;
		// QUERY FOR SEARCH
		vm.search = function(){
			console.log(vm.SelectSpareArray);
			if ($scope.selectMark == '' || $scope.selectModel == ''|| $scope.zap == '') {
				$alert({
					title: 'Некоторые поля пусты',
					content: '<i class="icon-cross" style="float:left;color:rgba(231,76,60,1);margin-right:5px;"></i>',
					animation: 'fadeZoomFadeDown',
					type: 'danger',
					duration: 5
				});
				return;
			}
			data = {
				search_mark:$scope.selectMark,
				search_model:$scope.selectModel,
				search_zap:vm.SelectSpareArray,
				year:$scope.year,
				volume:$scope.volume,
				additionalInfo:$scope.additionalInfo
			}
			$http.post('/api/client/search',data)
			.success(function(result){
				$rootScope.request_id = $cookieStore.get('request');
				$state.go('result-page');
			})
			.error(function(err,data){
				console.log(err);
				console.log(data);
			})
		}

	}]);
