angular.module('zap24')
	.controller('LoginController',['$http','$rootScope','$scope','$state','Auth','$cookieStore', function($http, $rootScope, $scope, $state, Auth, $cookieStore){
		$rootScope.isHome = false;
		$scope.login = function(){
			Auth.login({
				phone:'7'+$scope.phone,
				password:$scope.password
			});
		}
	}]);
