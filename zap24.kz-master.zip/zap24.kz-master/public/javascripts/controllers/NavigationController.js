angular.module('zap24')
	.controller('NavigationController',['$http','$rootScope','$scope','$state','Auth','MySocket', function($http, $rootScope, $scope, $state, Auth, MySocket){
    $scope.showLogout = false;
    $rootScope.$watch('currentUser',function(){
      if($rootScope.currentUser){
				MySocket.emit('join',$rootScope.currentUser);
        $scope.showLogout=true;
      }else{
        $scope.showLogout=false;
      }
    })
    $scope.logout = function() {
      Auth.logout();
    };

	}]);
