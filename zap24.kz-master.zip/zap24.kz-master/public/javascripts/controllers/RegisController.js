angular.module('zap24')
	.controller('RegisController',['$http','$rootScope','$scope','$state','Auth', function($http, $rootScope, $scope, $state, Auth){
		console.log('RegisController');
		$rootScope.isHome = false;
		//Фактори для регистрации
		$scope.signup = function(){
			Auth.signup({
				phone:$scope.phone,
				name:$scope.name,
				company:$scope.company,
				address:$scope.address,
				password:$scope.password
			});
		};
	}]);
