angular.module('zap24')
	.controller('ResultPageController',['$http','$rootScope','$scope','$state','$cookieStore','MySocket','$alert', function($http, $rootScope, $scope, $state, $cookieStore, MySocket, $alert){
		var vm = this;
		vm.search_result_array = [];
		vm.request = [];
		$rootScope.isHome = false;
		$http.get('/api/client/search_result/'+$cookieStore.get('request'))
			.success(function(search_result){
				vm.search_result_array = search_result[0].result;
			})
			.error(function(err,data){
				console.log('error');
			});


		vm.sendRequestFirst = function(){
			$scope.additionalFirst = true;
			$scope.additionalSecond = false;
		}

		vm.sendRequestSecond = function(){
			$scope.additionalSecond = true;
			$scope.additionalFirst = false;
		}

		vm.SendNumber = function(){
			var data = {
				request_ID:$cookieStore.get('request'),
				request_Phone:'7'+vm.phone
			};
			$http.post('/api/client/lead',data)
				.success(function(response){
					$alert({
            title: 'Ваш запрос отправлен',
            content: '<i class="icon-check" style="float:left;color:rgb(99,190,212);margin-right:5px;"></i>',
            animation: 'fadeZoomFadeDown',
            type: 'danger',
            duration: 5
          });
					$state.go('home');
					MySocket.emit('signup', data);
				})
				.error(function(error){
					console.log(error);
				})
		}

		vm.showPhone = function (index) {
			var one = document.getElementById("one"+index);
			var two = document.getElementById("two"+index);
			var three = document.getElementById("three"+index);
			one.style.display = "block";
			two.style.display = "none";
			three.style.display = "none";
			data = {
				seller:vm.search_result_array[index]
			}
			$http.post('/api/client/update-rate',data)
				.success(function(response){
					console.log(response);
				})
				.error(function(error){
					console.log(error);
				})
		}
	}]);
