angular.module('zap24')
	.controller('SellerePageController',['$http','$rootScope','$scope','$state','$cookieStore','MySocket', function($http, $rootScope, $scope, $state, $cookieStore, MySocket){
		var vm = this;
    vm.requestsArray = [];
    data = {
      seller_id:$rootScope.currentUser._id
    }
    var sendRequest = function(){
			$http.post('/api/client/get-leads',data)
				.success(function(response){
          vm.requestsArray = response;
					console.log(vm.requestsArray);
				})
				.error(function(error){
					console.log(error);
				})
		}
    sendRequest();

		MySocket.forward('admin',$scope);
        $scope.$on('socket:admin',function(ev,data){
					console.log(data.msg);
      });

    vm.btnAcceptLead = function(lead,index){
      lead.isChecked=true;
      lead.isAccepted=true;
      data = {
        LeadID:lead._id
      }
      $http.post('/api/client/accept-lead',data)
				.success(function(response){
          console.log(response);
				})
				.error(function(error){
					console.log(error);
				})
    }
    vm.btnDeclineLead = function(lead,index){
      lead.isChecked=true;
      lead.isAccepted=false;
      data = {
        LeadID:lead._id
      }
      $http.post('/api/client/decline-lead',data)
				.success(function(response){
          console.log(response);
				})
				.error(function(error){
					console.log(error);
				})
    }
	}]);
