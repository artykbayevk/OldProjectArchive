angular.module('zap24')
  .factory('Auth', ['$http', '$state', '$rootScope', '$alert','$cookieStore','MySocket', function($http, $state, $rootScope, $alert, $cookieStore, MySocket){
    $rootScope.currentUser = $cookieStore.get('user');
    return {
      signup: function(seller){
        return $http.post('/api/signup',seller)
        .success(function(response){
          $alert({
            title: 'Регистрация оформлена',
            content: '<i class="icon-check" style="float:left;color:rgb(99,190,212);margin-right:5px;"></i>',
            animation: 'fadeZoomFadeDown',
            type: 'danger',
            duration: 5
          });
          $state.go('login');
        })
        .error(function(response) {
          $alert({
            title: 'Ваши данные не верны',
            content: '<i class="icon-cross" style="float:left;color:rgba(231,76,60,1);margin-right:5px;"></i>',
            animation: 'fadeZoomFadeDown',
            type: 'danger',
            duration: 5
          });
        });
      },
      login: function(seller){
        return $http.post('/api/login',seller)
        .success(function(response){
					$alert({
						title: 'Добро пожаловать!',
						content: '<i class="icon-check" style="float:left;color:rgb(99,190,212);margin-right:5px;"></i>',
						animation: 'fadeZoomFadeDown',
						type: 'danger',
						duration: 5
					});
          $rootScope.currentUser = response;
          if($rootScope.currentUser.regFinished){
            $state.go('seller-page');
          }else{
            $state.go('additional-page');
          }
				})
				.error(function(err,data){
					$alert({
						title: 'Ваши данные не верны',
						content: '<i class="icon-cross" style="float:left;color:rgba(231,76,60,1);margin-right:5px;"></i>',
						animation: 'fadeZoomFadeDown',
						type: 'danger',
						duration: 5
					});
					console.log(err);
				});
      },
      logout: function() {
          return $http.get('/api/logout').success(function() {
            $rootScope.currentUser = false;
            $cookieStore.remove('user');
            $alert({
              content: 'You have been logged out.',
              placement: 'top-right',
              type: 'info',
              duration: 3
            });
            $state.go('home');
          });
        }
    }
  }]);
