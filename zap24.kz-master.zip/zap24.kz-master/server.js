'use strict'
var express = require('express');
var path = require('path');
var favicon = require('static-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');


//TELEGRAM

// var bot = require('telegram-node-bot')('210039547:AAGY249-xCqHAx5AbDBkZSHZnVEHK87ukW8');
// var new_user = {}

// var user_id = []; // это пустой массив просто для проверки
// var user_id = [64356750, 54937716, 207767224]; // это наши ИДшки просто для проверки

// 64356750 my ID
// 54937716 Kama's ID
// 207767224 Duisen's ID

//TELEGRAM

var routes = require('./server/routes/index');

var app = express();

mongoose.connect('mongodb://localhost/zap24kz');

app.set('port', process.env.PORT || 3000);
app.use(favicon());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


//TELEGRAM что то
// bot.router.when(['/start'], 'StartController').
//            when(['/register'], 'RegisterController').
//            when(['/continue'], 'ContinueController').
//            otherwise('OtherwiseController');
//
// // START CONTROLLER
// bot.controller('StartController', (res) => {
//     bot.for('/start', (res) => {
//         if (user_id.indexOf(res.user.id) !== -1){ // проверяет есть ли этот ИД в "базе"
//             res.routeTo('/continue'); // если есть, то перенаправляет на continue
//         } else {
//             var msg = res.message.text;
//             if (msg.length > 6){ // проверяет сообщение /start
//                 if (msg.split(' ')[1].startsWith('id')){
//
//                     // NOTE: если там /start id123456789, должен сверять с базой и сохранить телеграм-ид (res.user.id) к юзеру.
//                     // NOTE: эта ссылка в которой вы передаете ИД https://telegram.me/test_auto_bot?start=id1212356789
//                     // NOTE: вместо цифр после id можно передать ИД самого юзера чтобы потом сверять с базой
//
//                     // https://core.telegram.org/bots#deep-linking можете прочитать здесь
//                     // https://github.com/nickoala/telepot#deep-linking можете прочитать здесь (тут понятнее)
//
//
//                     console.log("registration from site!");
//                     console.log('{ \n   user ID:' + msg.split(' ')[1].substr(2));
//                     console.log("   telegram ID: " + res.user.id + "\n}");
//                     user_id.push(res.user.id); // просто добавляет ИД юзера в массив. можете убрать потом. это просто для того чтобы проверял есть ли такой телеграм ид
//                     res.sendMessage("Спасибо за регистрацию в нашем сервисе zap24.kz! \n Теперь вас будут видеть более 5000 покупателей ежедневно. ");
//                 } else { // это для того чтобы левый чувак не отправлял текст после /start
//                     console.log("wrong token");
//                     res.routeTo('/register');
//                 }
//             } else { // если там просто /start то оно регает с бота
//                 console.log("registration from telegram messenger");
//                 res.routeTo('/register');
//             }
//         }
//     })
// });
//
// // REGISTRATION CONTROLLER
// bot.controller('RegisterController', (res) => {
//     bot.for(['/register'], (res) => {
//         var options = {
//             reply_markup: JSON.stringify({
//                 resize_keyboard: true,
//                 one_time_keyboard: true,
//                 keyboard: [[{text: "Отправить данные", request_contact: true, request_location: true}]],
//             }),
//             reply_hide: JSON.stringify({
//                 hide_keyboard: true
//             })
//         }
//         res.sendMessage("Здравствуйте " + res.user.first_name + "! Добро пожаловать на наш бот! Чтобы продолжить регистрацию, нам нужны ваши контактные данные\n\nНажмите на кнопку => Отправить данные <=", options)
//         // отправляет сообщение и кпопку *ОТПРАВИТЬ ДАННЫЕ*
//         // если юзер не отправил свои контактные данные и отправил вместо этого левые тексты, то бот заново просит отправить данные
//         res.waitForRequest((res) => {
//             if (res.message.contact) {
//                 new_user = res.message.contact;
//                 var form = {
//                     company: {
//                         q: 'Теперь нам надо узнать о вашей компании подробнее. \n\nПожалуйста, введите название вашей компании (ИП, ТОО):',
//                         error: 'Вы кажется ввели некорректные данные, пожалуйста, повторно введите название вашей компании (ИП, ТОО):',
//                         validator: (input, callback) => {
//                             if (input['text']){
//                                 callback(true)
//                                 return
//                             }
//                             callback(false)
//                         }
//                     },
//                     address: {
//                         q: 'Теперь введите адрес: ',
//                         error: 'Вы кажется ввели некорректные данные, пожалуйста, повторно введите адрес:',
//                         validator: (input, callback) => {
//                             if (input['text']){
//                                 callback(true)
//                                 return
//                             }
//                             callback(false)
//                         }
//                     },
//                     parts: {
//                         q: 'Введите через запятую какие запчасти вы бы хотели продать (например: ходовка, стартер, фильтр): ',
//                         error: 'Вы кажется ввели некорректные данные, пожалуйста, повторно введите какие запчасти вы бы хотели продать:',
//                         validator: (input, callback) => {
//                             if (input['text']){
//                                 callback(true)
//                                 return
//                             }
//                             callback(false)
//                         }
//                     },
//                     cars: {
//                         q: 'Введите через запятую на какие модели машин вы бы хотели продать эти запчасти (например: BMW, Toyota, Nissan): ',
//                         error: 'Вы кажется ввели некорректные данные, пожалуйста, повторно введите какие запчасти вы бы хотели продать:',
//                         validator: (input, callback) => {
//                             if (input['text']){
//                                 callback(true)
//                                 return
//                             }
//                             callback(false)
//                         }
//                     }
//                 }
//                 res.runForm(form,  (result) => {
//                     new_user['additional'] = result;
//                     // new_user это наш объект с ИД юзера, телефон, и тд. крч полные данные.
//                     // вы должны добавить их в базу
//                     console.log(new_user);
//                     user_id.push(res.user.id) // просто добавляет ИД юзера в массив. можете убрать потом. это просто для того чтобы проверял есть ли такой телеграм ид
//                     res.sendMessage("Спасибо за регистрацию в нашем сервисе zap24.kz! \n Теперь вас будут видеть более 5000 покупателей ежедневно. ")
//                 })
//             } else {
//                 res.routeTo('/register')
//             }
//         })
//     })
// });
//
// bot.controller('ContinueController', (res) => {
//     bot.for(['/continue'], (res) => {
//         // просто контроллер для проверки если зареганный юзер напишет /start
//         res.sendMessage(res.user.first_name + " " + res.user.last_name + ', вы уже зарегистрированы!')
//     })
// });
//
// bot.controller('OtherwiseController', (res) => {
//     res.sendMessage("Вы ввели некорректные данные!")
// });
//
// // NOTE: тут пишете то что хотите если появился новый запрос (uncomment first :)
//
//
//
// for (var id of user_id) {
//     var msg = "📩  У вас новый запрос:  📩 \n\n" +
//                     "\t\t➡️ *ID:* 9548325\n" +
//                     "\t\t➡️ *Марка:* BMW\n" +
//                     "\t\t➡️ *Модель:* Х6\n" +
//                     "\t\t➡️ *Год выпуска:* 2010\n" +
//                     "\t\t➡️ *Об. двигателя:* 3.0\n" +
//                     "\t\t➡️ *Что нужно: ⚙* оптика\n" +
//                     "\t\t➡️ *Комментарии заказчика:* КПП типтроник, полный привод\n" +
//                     "\t\t➡️ *VIN:* " +
//                     "\n\nУ вас есть в наличии этот товар?";
//     bot.runInlineMenu(id, 'sendMessage', msg, {parse_mode : "Markdown"}, [
//         {
//             text: 'Да',
//             callback: ($) => {
//                 bot.sendMessage(id, "Спасибо! Клиент в скором времени свяжется с вами.")
//                 // тут пишете после что делать после того как они ответят ДА
//             }
//         },
//         {
//             text: 'Нет',
//             callback: ($) => {
//                 bot.sendMessage(id, "Спасибо что ответили!")
//                 // тут пишете после что делать после того как они ответят НЕТ
//             }
//         }
//     ], [2])
// }


// ЧТО ТО ОТ ТЕЛЕГРАМА



app.use('/api', routes);

app.get('*', function(req, res) {
  res.redirect('/#' + req.originalUrl);
});

app.use(function(err, req, res, next) {
  console.error(err.stack);
  res.send(500, { message: err.message });
});

var server = app.listen(app.get('port'), function() {
  console.log('Express server listening on port ' + app.get('port'));
});





var io = require('socket.io')();
io.attach(server);
io.sockets.on('connection',function(socket){
  socket.on('join',function(data){
    socket.join(data.phone);
  });
  socket.on('signup', function(data) {
    socket.broadcast.emit('admin',{msg:data});
  });

});

module.exports = app;
