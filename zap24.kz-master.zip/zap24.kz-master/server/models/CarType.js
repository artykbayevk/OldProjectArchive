var mongoose = require('mongoose');

var CarTypeSchema = mongoose.Schema({
  type:String,
  mark: String
});
module.exports = mongoose.model('CarType',CarTypeSchema);
