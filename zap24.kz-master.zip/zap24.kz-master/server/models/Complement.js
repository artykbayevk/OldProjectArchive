var mongoose = require('mongoose');

var ComplementSchema = mongoose.Schema({
  complement:String,
  spare: String
});

module.exports = mongoose.model('Complement',ComplementSchema);
