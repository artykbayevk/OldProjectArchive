var mongoose = require('mongoose');

var CustomerRequestSchema = mongoose.Schema({
  mark:String,
  model:String,
  spare:String,
  year:String,
  volume:String,
  description:String,
  result: [{type: mongoose.Schema.Types.ObjectId, ref: 'Seller'}],
  smsSended:Boolean
});

module.exports = mongoose.model('CustomerRequest',CustomerRequestSchema);
