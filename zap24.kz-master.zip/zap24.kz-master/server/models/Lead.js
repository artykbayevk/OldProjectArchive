var mongoose = require('mongoose');

var LeadSchema = mongoose.Schema({
  isChecked: Boolean,
  isAccepted: Boolean,
  request: {type: mongoose.Schema.Types.ObjectId, ref: 'CustomerRequest'},
  seller: {type: mongoose.Schema.Types.ObjectId, ref: 'Seller'},
  phone: String
});

module.exports = mongoose.model('Lead',LeadSchema);
