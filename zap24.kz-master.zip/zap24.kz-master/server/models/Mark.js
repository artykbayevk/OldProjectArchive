var mongoose = require('mongoose');

var CarMarkSchema = mongoose.Schema({
 	name:String,
 	name_rus: String,
 	models: [{type: mongoose.Schema.Types.ObjectId, ref: 'Model'}]
});

module.exports = mongoose.model('Mark',CarMarkSchema);
