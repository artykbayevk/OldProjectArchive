var mongoose = require('mongoose');

var CarModelSchema = mongoose.Schema({
	name:String,
	generations: [{type: mongoose.Schema.Types.ObjectId, ref: 'Generation'}],
	series: [{type: mongoose.Schema.Types.ObjectId, ref: 'Serie'}],
	modifications: [{type: mongoose.Schema.Types.ObjectId, ref: 'Modification'}],
	mark: {type: mongoose.Schema.Types.ObjectId, ref: 'Mark'},
});

module.exports = mongoose.model('Model',CarModelSchema);
