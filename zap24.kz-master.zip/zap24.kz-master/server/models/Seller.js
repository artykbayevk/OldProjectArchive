var mongoose = require('mongoose');
var bcrypt = require('bcryptjs');
var SellerSchema = mongoose.Schema({
	tel_id:{type:Number,default:0},
	name:String,
	company:String,
	phone:String,
	address:String,
	rate:{type:Number,default:0},
	zapchasti:String,
  komplekty: String,
	cars:String,
  marks: String,
	password:{type:String,default:'qwerty'},
	regFinished:{type:Boolean,default:false}
});

SellerSchema.pre('save', function(next) {
  var seller = this;
  if (!seller.isModified('password')) return next();
  bcrypt.genSalt(10, function(err, salt) {
    if (err) return next(err);
    bcrypt.hash(seller.password, salt, function(err, hash) {
      if (err) return next(err);
      seller.password = hash;
      next();
    });
  });
});

SellerSchema.methods.comparePassword = function(candidatePassword, cb) {
  bcrypt.compare(candidatePassword, this.password, function(err, isMatch) {
    if (err) return cb(err);
    cb(null, isMatch);
  });
};

module.exports = mongoose.model('Seller',SellerSchema);
