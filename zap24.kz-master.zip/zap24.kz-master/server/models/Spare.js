var mongoose = require('mongoose');

var SpareSchema = mongoose.Schema({
	name:String
});

module.exports = mongoose.model('Spare',SpareSchema);
