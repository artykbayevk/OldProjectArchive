var express = require('express');
var router = express.Router();

var carMarks = require('../models/Mark');
var carModels = require('../models/Model');
var sellers = require('../models/Seller');
var customerRequest = require('../models/CustomerRequest');
var Spares = require('../models/Spare');
var Lead = require('../models/Lead');
var complements = require('../models/Complement');
var carTypes = require('../models/CarType');

router.get('/getmarks/:str',function(req, res, next){
  carMarks.find({$or:[{name:  new RegExp('^'+req.params.str, 'i')}, {name_rus:  new RegExp('^'+req.params.str, 'i')}]})
    .populate('models','name')
      .exec(function(err,marks){
        if(err) return next(err);
        res.send(marks);
      });
    });

router.get('/change-password',function(req, res, next){
  sellers.find().exec(function(err,seller){
    seller.forEach(function(item,index){
      console.log("asd1");
      item.password = 'qwerty';
      item.save(function(){
        console.log("asd2");
      });
    })
    res.send(200);
  })
})

router.get('/getspares',function(req, res, next){
  var query = Spares.find();
  query.exec(function(err,spares){
    if(err) return next(err);
    res.send(spares);
  });
});

router.get('/getcomplements',function(req, res, next){
  var query = complements.find();
  query.exec(function(err,complements){
    if(err) return next(err);
    res.send(complements);
  });
});

router.get('/getcars',function(req, res, next){
  var query = carTypes.find();

  query.exec(function(err,cars){
    if(err) return next(err);
      res.send(cars);
  });
});

router.get('/getmarks',function(req, res, next){
  var query =carMarks.find();

  query.exec(function(err,cars){
      if(err) return next(err);
      res.send(cars);
  });
});

router.get('/customer-page/:id',function(req, res, next){
  Lead.find({request: req.params.id,isChecked : true})
  .select('_id isChecked isAccepted seller')
  .sort({isAccepted:-1})
  .populate('seller','name phone company address')
  .exec(function(err,response){
    if(err) return next(err);
    res.send(response);
  })
})

router.get('/search_result/:id', function(req, res, next){
  customerRequest.find({_id: req.params.id})
  .populate('result')
  .exec(function(err, response){
    if(err) return next(err);
    res.send(response);
  });
});

router.post('/search',function(req, res, next){
  var array=[];
  var j=0;
  var Request = new customerRequest({
    mark: req.body.search_mark,
    model: req.body.search_model,
    spare: req.body.search_zap,
    year: req.body.year,
    volume: req.body.volume,
    description: req.body.additionalInfo,
    smsSended:false
  });
  Request.save(function(err){
    if(err) return next(err);
  });
  req.body.search_zap.forEach(function(item, index) {
    sellers.find({$and:[
        {$or: [{marks: new RegExp(req.body.search_mark,'i')},{marks: new RegExp('все','i')}]},
        {$or:[{komplekty: new RegExp(item.trim().substring(0,4),'i')},{komplekty: new RegExp('все','i')}]}
      ]}
  ,function(err, selleres){
      selleres.forEach(function(item2,index2){
        Request.result.push(item2);
        //console.log(item2);
        // array.push(item2);
        });
        if(index == req.body.search_zap.length - 1 ){
          Request.save(function(err,response){
            if(err) return next(err);
            sendResponse(response);
          });
        }
      });
  });
      var sendResponse = function (response) {
        res.cookie('request', JSON.stringify(response._id));
        res.send(response._id);
      }

});

router.post('/lead',function(req,res,next){
  //req.body.cumstomerRequest_id

  customerRequest.findOne({_id:req.body.request_ID}).populate('result')
    .exec(function(err, response){
      response.result.forEach(function(item,index){
        var lead = new Lead({
          isChecked: false,
          isAccepted: false,
          request: response,
          seller: item,
          phone:req.body.request_Phone
        });
        lead.save(function(err){
          if(err) return next(err);
        });
      });
      res.send(200);
    });
});

router.post('/get-leads',function(req, res, next){
  Lead.find({seller: req.body.seller_id}).populate('request').exec(function(err,response){
      if(err) return next(err);
      res.send(response);
  });
});

router.post('/update-rate',function(req, res, next){
  sellers.findById(req.body.seller._id,function(err,seller){
    if(err) return next(err);
    seller.rate+=1;
    seller.save(function(error){
      if(error) return next(error);
      res.send(200);
    })
  })
})


var accountSid = 'AC118d8c9d77a8c926219d2ac3e75b2f8b';
var authToken = 'fbe20e8820157848755989911743f4d2';

var client = require('twilio')(accountSid, authToken);


router.post('/accept-lead', function(req, res, next){
  Lead.findById(req.body.LeadID, function(err, lead){
    if(err) return next(err);
    console.log(lead.request);
    customerRequest.findById(lead.request,function(error,request){
      if(error) return next(error);
      if(request.smsSended){
        lead.isChecked = true;
        lead.isAccepted = true;
        lead.save(function(err){
          res.status(200).send(lead);
        });

        console.log("Сообщение отправлено уже");

      }else{
        lead.isChecked = true;
        lead.isAccepted = true;
        lead.save(function(err){
          request.smsSended=true;
          request.save(function(er){
            if(er) return next(er);
            console.log('http://localhost:3000/customer-page/'+request._id);
            var href = 'http://localhost:3000/customer-page/'+request._id;
            var data = {
              text: 'Здравствуйте, вас приветсвует SMS-рассылка от zap24.kz. На ваш запрос ответили, вы можете перейти по этой ссылке '+ href +' и увидеть ответ, в будущем заходите на эту ссылку и смотрите другие ответы'
          }
            res.status(200).send(href);
            // client.messages.create({
            //     to: '+'+lead.phone,
            //     from: "+12195953257",
            //     body: data.text
            // }, function(err, message) {
            //     if (err){
            //       console.log('Not sended');
            //     } else {
            //       console.log('Sended');
            //       res.send(200);
            //     }
            // });
          })
        });
        console.log("Сообщение еще не отправлено");
      }
    })
  });
});


router.post('/decline-lead', function(req, res, next){
  Lead.findById(req.body.LeadID, function(err, lead){
    if(err) return next(err);
    lead.isChecked = true;
    lead.isAccepted = false;
    lead.save(function(err){
      res.status(200).send(lead);
    });
  });
});

module.exports = router
