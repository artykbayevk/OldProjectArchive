var express = require('express');
var router = express.Router();
var session = require('express-session');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var MongoStore = require('connect-mongo')(session);
var mongoose = require('mongoose');

var customerRequest = require('../models/CustomerRequest');
var carMarks = require('../models/Mark');
var carModels = require('../models/Model');
var sellers = require('../models/Seller');
/* GET home page. */


router.use(session({
  secret: 'keyboard cat',
  resave: true,
  saveUninitialized:true,
  store: new MongoStore({ mongooseConnection: mongoose.connection })
}));
router.use(passport.initialize());
router.use(passport.session());

passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  sellers.findById(id,'phone regFinished',function(err, user) {
    done(err, user);
  });
});

function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) next();
  else res.send(401);
}

passport.use(new LocalStrategy({ usernameField: 'phone' }, function(phone, password, done) {
  sellers.findOne({ phone: phone }, function(err, seller) {
    if (err) return done(err);
    if (!seller) return done(null, false);
    seller.comparePassword(password, function(err, isMatch) {
      if (err) return done(err);
      if (isMatch) return done(null, seller);
      return done(null, false);
    });
  });
}));

router.post('/login', passport.authenticate('local'), function(req, res) {
  res.cookie('user', JSON.stringify(req.user));
  console.log(req.user);
  res.send(req.user);
});

router.post('/signup', function(req, res, next) {
  var seller = new sellers({
    name: req.body.name,
    company:req.body.company,
    phone:'7'+req.body.phone,
    address:req.body.address,
    password: req.body.password
  });
  seller.save(function(err) {
    if (err) return next(err);
    console.log(seller);
    res.send(200);
  });
});

router.post('/finish-reg',function(req, res, next){
  console.log(req.body);
  var query = sellers.findOne({phone:req.body.number});
  query.exec(function(err, seller){
    if(err) return next(err);
    seller.zapchasti = req.body.complement;
    seller.komplekty = req.body.spare;
    seller.cars = req.body.car;
    seller.marks = req.body.mark;
    seller.regFinished = true;
    seller.save(function(error){
      if(error) return next(error);
      console.log(seller);
      res.send(200);
    })

  });
});

router.get('/logout', function(req, res, next) {
  req.logout();
  res.send(200);
});

router.use(function(req, res, next) {
  if (req.user) {
    res.cookie('user', JSON.stringify(req.user));
  }
  next();
});


router.use('/client',require('./client'));
router.use('/parse',require('./parse'));

module.exports = router;
