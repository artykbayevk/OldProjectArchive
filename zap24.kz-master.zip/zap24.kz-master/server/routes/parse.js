var express = require('express');
var router = express.Router();
var carMarks = require('../models/Mark');
var carModels = require('../models/Model');
var sellers = require('../models/Seller');
var spares = require('../models/Spare');
var Complements = require('../models/Complement');
var carTypes = require('../models/CarType');

/* GET home page. */

router.post('/parse-mark-model',function(req,res,next){
  carMarks.findOne({name: req.body.mark_name}).exec(function(err,car){
    if(err) return next(err);
    if(!car){
      var mark = new carMarks({
        name: req.body.mark_name,
        name_rus: req.body.mark_name_rus
      });
      mark.save(function(err){
        if(err) return next(err);
        var model = new carModels({
          name: req.body.model_name,
          mark: mark
        });
        model.save(function(err){
          if(err) return next(err);
          mark.models.push(model);
          mark.save(function(err,mar){
            if(err) return next(err);
            res.send(mar);
          });
        });
      });
    }
    else{
      var model = new carModels({
        name: req.body.model_name,
        mark: car
      });
      model.save(function(err){
        car.models.push(model);
        car.save(function(err){
          if(err) return next(err);
          res.send(200);
      });
      });
    }
  });
});

router.post('/parse-model-generation',function(req,res,next){
  carModels.findOne({name: req.body.model_name}).exec(function(err,car){
    if(err) return next(err);
    if(!car){
      res.send(404);
    }
    else{
      var generation = new carGenerations({
        name: req.body.generation_name,
        year_begin: req.body.generation_year_begin,
        year_end: req.body.generation_year_end,
        model: car
      });

      generation.save(function(err){
        if(err) return next(err);
        car.generations.push(generation);
        car.save(function(err){
          if(err) return next(err);
          res.send(200);
        });
      });
    }
  });
});

router.post('/parse-model-serie',function(req,res,next){
  carModels.findOne({name: req.body.model_name}).exec(function(err,car){
    if(err) return next(err);
    if(!car){
      res.send(404);
    }
    else{
      var serie = new carSeries({
        name: req.body.serie_name,
        model: car
      });

      serie.save(function(err){
        if(err) return next(err);
        car.series.push(serie);
        car.save(function(err){
          if(err) return next(err);
          res.send(200);
        });
      });
    }
  });
});

router.post('/parse-model-serie-modification',function(req,res,next){
  carModels.findOne({name: req.body.model_name}).exec(function(err,car){
    if(err) return next(err);
    if(!car){
      next(err);
    }
    else{
      carSeries.findOne({name: req.body.serie_name}).exec(function(err,car2){
        if(err) return next(err);
        if(!car2){
          next(err);
        }
        else{
          var modification = new carModifications({
            name: req.body.modification_name,
            year_begin: req.body.year_begin,
            year_end: req.body.year_end,
            model: car,
            serie: car2
          });

          modification.save(function(err){
            if(err) return next(err);
            car.modifications.push(modification);
            car.save(function(err){
              if(err) return next(err);
              car2.modifications.push(modification);
              car2.save(function(err){
                if(err) return next(err);
                res.send(200);
              });
            });
          })
        }
      });
    }
  });
});

router.post('/parse-cartype',function(req,res,next){
  var type = new carTypes({
    type: req.body.type,
    mark: req.body.mark
  });
  type.save(function(err){
    if(err) return next(err);
    res.send(200);
  });
});

router.post('/parse-seller',function(req,res,next){
  var seller = new sellers({
    tel_id: req.body.tel_id,
    name: req.body.name,
    company: req.body.company,
    phone: req.body.phone,
    address: req.body.address,
    rate: 0,
    zapchasti: req.body.zapchasti,
    komplekty: req.body.komplekty,
    cars: req.body.cars,
    marks: req.body.marks
  });
  seller.save(function(err){
    if(err) return next(err);
    res.send(200);
  });
});

router.post('/parse-complement-spare',function(req,res,next){
  var komplekty = req.body.spare.split(',');
  komplekty.forEach(function(item,index){
    var spare = new spares({
      name: item.trim()
    });
    spare.save(function(err,response){
      console.log(response);
    });
  });
  res.send(200);
});

router.post('/parse-complement',function(req,res,next){
    var complement = new Complements({
      complement: req.body.complement,
      spare: req.body.spare
    });
    complement.save(function(err,response){
      res.send(response);
    });
});

router.post('/parse-cartype',function(req,res,next){
  var type = new carTypes({
    type: req.body.type,
    mark: req.body.mark
  });
  type.save(function(err){
    if(err) return next(err);
    res.send(200);
  });
});

module.exports = router;
